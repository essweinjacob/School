public interface Reproduction {
    public abstract String modeOfReproduction();
}
