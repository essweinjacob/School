#ifndef PHONE_FMT_
#define PHONE_FMT_

void phone_fmt(char *number);

#endif
