#ifndef SUM_H_
#define SUM_H_

float sum(float *a, float N);

#endif
