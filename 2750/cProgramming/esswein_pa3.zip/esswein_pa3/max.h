#ifndef MAX_H_
#define MAX_H_

float max(float *a, float N);

#endif
