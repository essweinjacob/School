#ifndef MIN_H_
#define MIN_H_

float min(float *a, float N);

#endif
