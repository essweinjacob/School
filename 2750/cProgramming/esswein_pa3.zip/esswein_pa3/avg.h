#ifndef AVG_H_
#define AVG_H_

float avg(float *a, float N);

#endif
