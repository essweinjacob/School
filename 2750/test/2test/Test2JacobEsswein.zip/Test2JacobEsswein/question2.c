#include <stdio.h>
#include <string.h>

void main(){
    char string[100];
    scanf("%s", string);
    printf("Original string: %s\n", string);

    replace(string);


}
