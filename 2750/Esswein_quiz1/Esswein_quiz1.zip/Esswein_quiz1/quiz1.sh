echo "My name is Jacob Esswein and I am currently pursuing a Bachelors of Science Computer Science degree
here at University of Missouri St. Louis. Coding classes I have taken prior to this are a Python coruse at St.
Charles Community College and two C++ courses, a Java/Object Oriented Course and a Web Design course here at UMSL and next week I will begin a Management Information Systems Internship at FleishmanHillard."
